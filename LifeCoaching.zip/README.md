# LifeCoaching
LifeCoaching landing page 


1. make sure you have Python installed on your system.
2. In terminal pip install Flask
3. run python app.py
4. Open a web browser and navigate to http://127.0.0.1:5000/